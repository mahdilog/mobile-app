import { RootContainer } from "@/components/defaultLayout";
import { Text, View } from "react-native";

const Tour = () => {
  return (
    <RootContainer>
      <Text>12</Text>
    </RootContainer>
  );
};

export default Tour;
