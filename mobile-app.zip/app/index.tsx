//@ts-nocheck
import React from "react";
import { useKeenSliderNative } from "keen-slider/react-native";
import { RootContainer } from "@/components/defaultLayout";
import { Text, View } from "react-native";

export default function App() {
  const slides = 6;
  const slider = useKeenSliderNative({
    mode: "free-snap",
    slides: {
      number: slides,
      origin: "center",
      perView: 2,
      spacing: 15,
    },
  });

  return (
    <RootContainer>
      <View style={styles.slider} {...slider.containerProps}>
        {[...Array(slides).keys()].map((key) => {
          return (
            <View key={key} {...slider.slidesProps[key]}>
              <View style={{ ...styles.slide, backgroundColor: colors[key] }}>
                <Text style={styles.text}>Slide {key + 1}</Text>
              </View>
            </View>
          );
        })}
      </View>
    </RootContainer>
  );
}

const colors = [
  "#407CFE",
  "#FF6540",
  "#6AFC52",
  "#3FD2FA",
  "#FF3E5E",
  "#8A45FF",
];

const styles = {
  slider: {
    backgroundColor: "#fff",
    overflow: "hidden",
    width: "100%",
    height: 160,
    broderRadius: 20,
  },
  slide: {
    width: "100%",
    height: 160,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "black",
    broderRadius: 20,
  },
  text: {
    color: "white",
    fontSize: 30,
  },
};
