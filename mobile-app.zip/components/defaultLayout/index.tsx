import { ReactNode } from "react";
import { View } from "react-native";
import Ionicons from "@expo/vector-icons/Ionicons";
import { usePathname, useRouter } from "expo-router";

export const RootContainer = ({ children }: { children: ReactNode }) => {
  const pathname = usePathname();
  const router = useRouter();
  return (
    <View className="p-6 bg-primary h-screen w-screen">
      <View
        className="flex flex-nowrap w-full flex-col mb-4"
        style={{
          flexDirection: "row",
          justifyContent: "space-between",
        }}
      >
        <View className="w-11 h-11 bg-white flex justify-center items-center shadow-sm shadow-gray-400 rounded-full">
          <Ionicons name="people-outline" size={24} color="#ADB4BD" />
        </View>
        <View className="w-11 h-11 bg-white flex justify-center items-center shadow-sm shadow-gray-400 rounded-full">
          <Ionicons name="search-outline" size={24} color="#ADB4BD" />
        </View>
      </View>
      <View>{children}</View>
      <View className="absolute bg-slate-50 h-24 w-screen bottom-0 rounded-3xl p-6 flex justify-between items-center flex-row">
        <View onTouchEnd={() => router.navigate("/tour")}>
          <Ionicons
            name={pathname === "/tour" ? "earth" : "earth-outline"}
            size={24}
            color={pathname === "/tour" ? "#163C9F" : "#ADB4BD"}
          />
        </View>
        <View onTouchEnd={() => router.navigate("/")}>
          <Ionicons
            name={pathname === "/" ? "home" : "home-outline"}
            size={24}
            color={pathname === "/" ? "#163C9F" : "#ADB4BD"}
          />
        </View>
        <View>
          <Ionicons name="ticket-outline" size={24} color="#ADB4BD" />
        </View>
      </View>
    </View>
  );
};
